import requests
import os
def handler(event,context):
    vm_private_ip = os.environ['VM_PRIVATE_IP']
    url = "http://"+vm_private_ip+"/index.html"
    response  = requests.get(url)
    return response.text